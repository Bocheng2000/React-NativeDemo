/**
 * Created by chuchengbo on 2018/5/12.
 */
import React, { Component } from 'react';
import {
    StyleSheet,
    Text,
    View,
    SectionList
} from 'react-native';

export default class SectionListDemo extends Component {

    render() {
        return (
            <View style={styles.container}>
                <SectionList
                    sections={[
                        {title:'A',key:'a',data:['aliht','asdk','asdde']},
                        {title:'C',key:'b',data:['casd','cdasq','cdsaasqw','cdsa']}
                    ]}
                    renderItem={({item}) => <Text style = {styles.item}>{item}</Text>}
                    rederSectionHeader={({section}) => <Text style={styles.sectionHeader}>{section.title}</Text>}
                />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container:{
        flex:1,
        paddingTop:22,
        width:100,
    },
    item:{
        backgroundColor:'red',

        padding:10,
        fontSize:20,
        height:44,
    },
    sectionHeader:{
        paddingTop:10,
        paddingLeft:30,
        paddingRight:21,
        paddingBottom:3,
        fontSize:13,
        fontWeight:'bold',
        backgroundColor:'rgba(247,245,231,1.0)'

    }

})
