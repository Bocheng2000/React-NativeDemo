
/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image
} from 'react-native';

export default class LotsOfStyles extends Component {
  render() {
    return (
      <View >
        <Text style = {styles.bigBlue}>just blue</Text>
        <Text style = {styles.red}>just red</Text>
        <Text style = {[styles.bigBlue ,styles.red]}>from blue to red</Text>
        <Text style = {[styles.red , styles.bigBlue]}>from red to blue</Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
    bigBlue:{
        color:'blue',
        fontWeight:'bold',
        fontSize : 30,
    },
    red:{
        color:'red',
    },
});
