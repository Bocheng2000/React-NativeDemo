/**
 * Created by chuchengbo on 2018/5/12.
 */
import React, { Component } from 'react';
import {
    StyleSheet,
    Text,
    View,
    AlertIOS,
} from 'react-native';

export default class AlertIOSDemo extends Component {
    render() {
        return (
            <View style={{flexDirection:'column',flex:1,justifyContent:'space-between',alignItems:'center'}}>
                <View style={{width:290,height:50,backgroundColor:'red'}}></View>
                <View style={{width:290,height:50,backgroundColor:'blue'}}></View>
                <View style={{width:290,height:50,backgroundColor:'green'}}></View>
            </View>
        );
    }
}
const styles = StyleSheet.create({
    item:{
        margin:10,
        height:30,
        borderWidth:1,
        padding:6,
        borderColor:'#ddd',
        textAlign:'center'
    },
});
