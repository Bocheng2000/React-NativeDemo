/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image
} from 'react-native';

class Greeting extends Component {
    render(){
        return (
            <Text>hello {this.props.name}!</Text>
        );
    }
}

// class ImageShow extends Component {
//     render(){
//         let picUrl={uri:'https://upload.wikimedia.org/wikipedia/commons/d/de/Bananavarieties.jpg'};
//         return (
//                 <Image source={picUrl} style{{width:20,height:30}}/>
//         );
//     }
// }

export default class LotsOfGreetins extends Component {
  render() {
    return (
      <View style={{alignItems:'center'}}>
        <Greeting name='ccb'/>
        <Greeting name='glb'/>
        <Greeting name='cf'/>
      </View>
    );
  }
}
