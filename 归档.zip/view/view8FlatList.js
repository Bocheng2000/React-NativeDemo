/**
 * Created by chuchengbo on 2018/5/12.
 */
import React, { Component } from 'react';
import {
    StyleSheet,
    Text,
    View,
    FlatList
} from 'react-native';

export default class FlatListDemo extends Component {

    render() {
        return (
            <View style={styles.container}>
                <FlatList
                    data={[
                        {key:'bob'},
                        {key:'ccb'},
                        {key:'ccb1'},
                        {key:'123'},
                        {key:'isd'},
                        {key:'dka'},
                        {key:'sood'},
                        {key:'asd'},
                        {key:'ccb3'},
                        {key:'ccb14'},
                        {key:'123as5'},
                        {key:'iszd'},
                        {key:'dkza'},
                        {key:'sooxd'},
                        {key:'asdf'},
                        {key:'ccbwq'},
                        {key:'ccbq1'},
                        {key:'123qw'},
                        {key:'isqwd'},
                        {key:'dkaqw'},
                        {key:'sood23'},
                        {key:'asxcd'},
                    ]}
                    renderItem={({item}) => <Text style = {styles.item}>{item.key}</Text>}
                />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container:{
        flex:1,
        paddingTop:22,
        width:100,
    },
    item:{
        backgroundColor:'red',

        padding:10,
        fontSize:20,
        height:44,
    }

})
