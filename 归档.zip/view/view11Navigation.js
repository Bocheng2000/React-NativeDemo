/**
 * Created by chuchengbo on 2018/5/12.
 */
import React, { Component } from 'react';
import {
    StyleSheet,
    Text,
    View,
    TextInput,
    Button
} from 'react-native';
import {
    StackNavigator
} from 'react-navigation';
import View1Greeting from './view1Greeting';
import Blinking from './view2blink';

const StackNavigatorDemo = StackNavigator({
    View1Greeting:{screen:MainScreenTest1},
    Blinking:{screen:view2blink}
});

export default class MainScreenTest extends Component {
    render(){
        return (
            <AppNagivation />
        )
    }
}

const AppNagivation = () =>(
    <StackNavigatorDemo />
);

class MainScreenTest1 extends Component {
  static navigationOptions = {
    title: 'Welcome',
  };
  render() {
    const { navigate } = this.props.navigation;
    return (
      <Button
        title="Go to Jane's profile"
        onPress={() =>
          navigate('Profile', { 'name': 'Jane' })} />
    );
  }
}

const view2blink = () =>(
    <Blinking />
);

const styles = StyleSheet.create({
    container:{
        height:40,
    },

})
