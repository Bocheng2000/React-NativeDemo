/**
 * Created by chuchengbo on 2018/5/12.
 */
import React, { Component } from 'react';
import {
    StyleSheet,
    Text,
    View,
    TextInput,
    Button
} from 'react-native';

export default class NetworkTest extends Component {
    constructor(props){
        super(props);
        this.state = {title:''};
    }

    fetchData = (enableCallback)=>{
        this.setState({title:"loading..."});
        fetch('https://facebook.github.io/react-native/movies.json')
            .then((response) => response.json() )
            .then((jsondata)=>{
                console.log(jsondata);
                this.setState({title:jsondata.title})
            })
            .catch((error)=>{
                console.log(error);
            });
    };

    render() {
        return (
            <View style={styles.container}>
                <Button onPress={this.fetchData} text="提交" title="hah"/>
                <Text>{this.state.title}</Text>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container:{
        height:40,
    },

})
