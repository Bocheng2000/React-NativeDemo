/**
 * Created by chuchengbo on 2018/5/12.
 */
import React, { Component } from 'react';
import {
    StyleSheet,
    Text,
    View,
    ScrollView,
    Image
} from 'react-native';

export default class ScrollViewDemo extends Component {
    constructor(props){
        super(props);
        this.state = {};
    }

    render() {
        return (
            <ScrollView>
                <Text style={styles.text}>scroll me</Text>
                <Image style={styles.image} source={require('./image/ReactNativeLogo.png')}/>
                <Image source={require('./image/ReactNativeLogo.png')}/>
                <Image source={require('./image/ReactNativeLogo.png')}/>
                <Image source={require('./image/ReactNativeLogo.png')}/>
                <Text style={styles.text}>scroll me</Text>
                <Image source={require('./image/ReactNativeLogo.png')}/>
                <Image source={require('./image/ReactNativeLogo.png')}/>
                <Image source={require('./image/ReactNativeLogo.png')}/>
                <Image source={require('./image/ReactNativeLogo.png')}/>
                <Text style={styles.text}>scroll me</Text>
                <Image source={require('./image/ReactNativeLogo.png')}/>
                <Image source={require('./image/ReactNativeLogo.png')}/>
                <Image source={require('./image/ReactNativeLogo.png')}/>
                <Image source={require('./image/ReactNativeLogo.png')}/>
                <Text style={styles.text}>scroll me</Text>
                <Image source={require('./image/ReactNativeLogo.png')}/>
                <Image source={require('./image/ReactNativeLogo.png')}/>
                <Image source={require('./image/ReactNativeLogo.png')}/>
                <Image source={require('./image/ReactNativeLogo.png')}/>
            </ScrollView>
        );
    }
}

const styles = StyleSheet.create({
    container:{
        height:40,
    },
    text:{
        fontSize:90,
    },
    image:{
        padding:10,
        width:100,
        height:100,
        marginBottom:20,
        borderRadius:20,
    }
})
