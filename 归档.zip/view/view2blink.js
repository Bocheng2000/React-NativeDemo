
/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image
} from 'react-native';

class Blink extends Component {
    //constructor 初始化数据
    constructor(props){
        super(props);
        this.state = {showText:true};
        setInterval(()=>{
            this.setState(previousState=>{
                return {showText:!previousState.showText};

            });
        },1000);
    }
    render(){
        let display = this.state.showText ? this.props.text : '';
        return (
            <Text style={{color:'red'}}>{display}</Text>
        );
    }
}

export default class Blinking extends Component {
  render() {
    return (
      <View >
        <Blink text='I'/>
        <Blink text='love'/>
        <Blink text='you'/>
      </View>
    );
  }
}
