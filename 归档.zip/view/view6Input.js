/**
 * Created by chuchengbo on 2018/5/12.
 */
import React, { Component } from 'react';
import {
    StyleSheet,
    Text,
    View,
    TextInput
} from 'react-native';

export default class InputTest extends Component {
    constructor(props){
        super(props);
        this.state = {textContent:''};
    }

    render() {
        return (
            <View style={{padding:20}}>
                <TextInput
                    style={styles.textInputStyle}
                    placeholder="just enter your name "
                    onChangeText={(textContent) => this.setState({textContent})}
                />
                <Text style={styles.textShowStyle}>
                    {this.state.textContent.split(' ').map((word) => word && '[]').join(' ')}
                </Text>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    textInputStyle:{
        height:40,
    },
    textShowStyle:{
        padding:10,
        fontSize:43,
    }
})
