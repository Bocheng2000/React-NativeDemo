/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Button,
  Image
} from 'react-native';
import { StackNavigator ,TabNavigator,DrawerNavigator} from 'react-navigation';

import LotsOfGreetins from './view/view1Greeting';
import Blinking from './view/view2blink';
import LotsOfStyles from './view/view3LotsOfStyle';
import AlertIOSDemo from './view/view4AlertIos';
import FlexTest from './view/view5Flex';
import InputTest from './view/view6Input';
import ScrollViewDemo from './view/view7ScrollView';
import FlatListDemo from './view/view8FlatList';
import SectionListDemo from './view/view9SectionList';
import NetworkTest from './view/view10Network';

type Props = {};

class HomeTitleLogo extends Component{
    render(){
        return(
        <Image
        source = {require('./view/image/ReactNativeLogo.png')}
        style = {{width:30,height:30}}
    />
)}
}

class MyModalScreen extends Component {
    render(){
        return(
            <View style={{marginTop:30}}>
                <Text>this is a modal screen</Text>
                <Button onPress={()=>this.props.navigation.goBack()} title="dismiss"/>
            </View>
        )
    }
}

class HomeScreen extends Component {
    static navigationOptions = ({navigation})=>{
        const params = navigation.state.params || {};
        return {
            headerLeft:(
                <Button onPress={()=>navigation.navigate('MyModal')} title='Modal' color='blue'/>
            ),
            headerRight:(
                <Button onPress={params.increaseCount} title='+1' color='blue'/>
            ),
            headerTitle:<HomeTitleLogo />,
        };

        // title:'首页',
        // headerStyle:{
        //     backgroundColor:'red',
        // },
        // headerTintColor:'white',
        // headerTitleStyle:{
        //     fontWeight:'bold',
        // }
    };
    componentWillMount(){
        this.props.navigation.setParams({increaseCount:this._increaseCount});
    }

    state = {
        count:10,
    };
    _increaseCount = () =>{
        this.setState({count:this.state.count +1});
    };
  render() {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <Text>{this.state.count}</Text>
        <Blinking />
        <Button
            title='go to detail'
            onPress={()=>this.props.navigation.navigate('Details',{
                itemId:86,
                otherParam:'首页传递的其他参数'
            })}
        />
      </View>
    );
  }
}



class DetailsScreen extends Component {
    static navigationOptions = ({navigation,navigationOptions}) =>{
        const {params} = navigation.state;
        return {
            title:params?params.otherParam:'没传递过来标题啊',
            headerStyle:{
                backgroundColor:'red',
            },
            headerTintColor:navigationOptions.headerStyle.backgroundColor,
            headerLeft:(
                <Button title = "返回" onPress = {()=>navigation.goBack()}/>
            )
        };
    };
  render() {
      const {navigation} = this.props;
      const itemId = navigation.getParam('itemId');
      const otherParam = navigation.getParam('otherParam');
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <Text>itemId:{JSON.stringify(itemId)}</Text>
        <Text>otherParam:{JSON.stringify(otherParam)}</Text>
        {/* <ScrollViewDemo /> */}
        <Button
            title='go to detail again'
            onPress={()=>this.props.navigation.push('Details',{
                itemId:Math.floor(Math.random()*100),
                otherParam:'details的传递参数'
            })}
        />
        <Button
            title='go to home navigate'
            onPress={()=>this.props.navigation.navigate('Home')}
        />
        <Button
            title='go to home popToTop'
            onPress={()=>this.props.navigation.popToTop()}
        />
        <Button
            title='go to back'
            onPress={()=>this.props.navigation.goBack()}
        />
        <Button
            title="更新当前界面的参数(标题)"
            onPress={()=>this.props.navigation.setParams({otherParam:'这是更新后的标题'})}
        />
      </View>
    );
  }
}

const MainStack = StackNavigator(
{
  Home:HomeScreen,
  Details: DetailsScreen,
},
{
  initialRouteName: 'Home',
  navigationOptions : {
      title:'首页',
      headerStyle:{
          backgroundColor:'green',
      },
      headerTineColor:'white',
      headerTitleStyle:{
          fontWeight:'bold',
      },
      headerLeft:(
          <Button onPress={()=>alert('this is a button')} title='info' color='blue'/>
      ),
},
}
);

const RootStack = StackNavigator(
    {
        Main:MainStack,
        MyModal:MyModalScreen,
    },
    {
        mode:'modal',
        headerMode:'none',
    }
);

export default class App extends Component {
    render(){
        return <RootStack />
    }
}
//标准话APP扩展方式
// export default class App extends Component<Props> {
//   render() {
//     return (
//       <View style={styles.container}>
//
//         {/* <LotsOfGreetins /> */}
//         {/* <Blinking /> */}
//         {/* <LotsOfStyles /> */}
//         {/* <AlertIOSDemo /> */}
//         {/* <FlexTest /> */}
//         {/* <InputTest /> */}
//         {/* <ScrollViewDemo /> */}
//         {/* <FlatListDemo /> */}
//         {/* <SectionListDemo /> */}
//         {/* <NetworkTest /> */}
//         <StackNavigator />
//       </View>
//     );
// }
// }
